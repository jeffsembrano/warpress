 <!-- footer content -->
        <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <?php wp_footer(); ?>



      <!-- jQuery -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/jquery/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/bootstrap/dist/js/bootstrap.min.js"></script>
   <!-- FastClick -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/fastclick.js"></script>
    <!-- NProgress -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/chart/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/gauge/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/Flot/jquery.flot.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/Flot/jquery.flot.pie.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/Flot/jquery.flot.time.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/Flot/jquery.flot.stack.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/jquery.flot.orderBars.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/jquery.flot.spline.min.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/date/date.js"></script>
    <!-- JQVMap -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/jqvmap/jquery.vmap.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/min/moment.min.js"></script>
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="/wordpress/wordpress/wp-content/themes/gentelellasample/js/custom.min.js"></script>


  </body>
</html>
